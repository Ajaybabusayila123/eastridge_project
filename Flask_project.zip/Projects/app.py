from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship, backref
import datetime 
  
### create app
app = Flask(__name__)  

### Config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///invoices.sqlite3'  
app.config['SECRET_KEY'] = "secret key"  
  
### sqlalchemy
db = SQLAlchemy(app)  

### Models
class Invoice(db.Model):  
   __tablename__ = 'invoice'
   id = db.Column(db.Integer, primary_key = True) 
   place = db.Column(db.String)
   invoice_date = db.Column(db.Date, nullable = False)
   

   def __init__(self, date, place):  
        self.invoice_date = datetime.datetime.strptime(date, "%Y-%m-%d").date()
        self.place = place

class InvoiceItem(db.Model):  
    __tablename__ = 'invoice_item'
    id = db.Column(db.Integer, primary_key = True) 
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)
    invoice = db.relationship("Invoice", backref=backref("invoice", uselist=False))
    units = db.Column(db.Integer)  
    description = db.Column(db.String(200))  
    amount = db.Column(db.Float(50))
    
    def __init__(self, invoice_id, units, description, amount):  
        self.invoice_id = invoice_id
        self.units = units
        self.description = description
        self.amount = amount

    def __repr__(self):
        return '<InvoiceItem %r>' % self.description

### routes
########################################################################
@app.route('/')  
def home():
    return render_template('home.html') 

@app.route('/invoice')  
def list_invoices():  
    data = Invoice.query.all()
    return render_template('list_invoices.html', Invoices=data )  
 

@app.route('/invoice/add', methods = ['GET', 'POST'])  
def addInvoice():  
   if request.method == 'POST':  
        #print(request.form)
        if not request.form['date']:  
            flash('Please enter all the fields', 'error')  
        else:  
            invoice = Invoice(
                request.form['date'], 
                request.form['place']
            )  
           
            db.session.add(invoice)  
            db.session.commit()  
            flash('Record was successfully added')  
            return redirect(url_for('list_invoices'))  
   return render_template('add_invoice.html')  


@app.route('/invoice/item/add', methods = ['GET', 'POST']) 
def addInvoiceItem():
    if request.method == 'POST':  
        print(request.form)
        if not request.form['invoice_id'] or not request.form['units'] or not request.form['description'] or not request.form['amount']:  
            flash('Please enter all the fields', 'error')  
        else:  
            invoice_item = InvoiceItem(
                request.form['invoice_id'], 
                request.form['units'], 
                request.form['description'], 
                request.form['amount']
            )  
           
            db.session.add(invoice_item)  
            db.session.commit()  
            flash('Record was successfully added')  
            return redirect(url_for('list_invoices'))  
    return render_template('add_invoice_item.html')  


@app.route('/invoice/item', methods = ['GET', 'POST']) 
def getInvoiceItem():
    data = InvoiceItem.query.all()
    return render_template('list_invoice_items.html', Invoice_Item=data )  


if __name__ == '__main__':  
   db.create_all()  
   app.run(debug = True)